
	DENTRO DEL ARCHIVO DUPER-SHORT ESTAN ESCRITAS OTRA FORMA DE HACER FUNCIONAR ESTO, SI NO FUNCIONA ESTA.


	-SI LO QUE ESTA AHI NO FUNCIONA, FAVOR DE IMPORTAR LA LIBRERIA NUM2WORDS
   pip install num2words   (desde la terminar de anaconda promt) y pegar el
archivo tommy.py en la carpeta que se crea dentro de: "nombre del proyecto que se tiene"\venv\lib\site-package\num2words
	-Este modificara la libreria para que el file duper-short.py funcione... pero el archivo duper-short.py tiene que
    estar pegado en la carpeta a la que anteriormente me referi como: "nombre del priyecto que se tiene".

########################################################################################################################

NOTA: Si esta leyendo esto despues del miercoles, ya tengo mi propia biblioteca en pypi.org para que cualquier
usuario la descarge así como num2words, y no tenga que hacer lo que le indico. Se supone pues que el martes en la tarde
voy a subirla.

########################################################################################################################
