'''
ESTO FUNCIONA SIN IMPORTAR LA LIBRERIA
from num2words import num2words
n=eval(input("Inserta cualquier número:\n\n"))
print('\nSon:',num2words(int(n), lang='es'),'pesos con',int((n-int(n))*100),'/100 M.X.')
'''

"""
ESTO FUNCIONA SIN MODIFICAR LA LIBRERIA
from num2words import num2words
print('\nSon:',num2words(int(input("Cuántos pesos?\n")), lang='es'),'pesos con',int(input('Y decimales?\n')),'/100 M.X.')
"""


print('Hola Maestra ;)\n')    #Si pones "from tommy import T", dejas pegado en el mismo niver el archivo de tommy con este y borras tommy de aqui abajo... tambien funciona, pero el punto era crear mi propia libreria midificando la de num2words.

#ESTE ES MAS CHIDO PORQUE EN EL FILE TOMMY SE SOLUCIONA LO DE TERMINAR EN 'UNO' POR 'UN'... ademas solo son 2 lineas!!!
from num2words import tommy
print(tommy.T((eval(input('Inseta un numero:\n\n          ')))))


    # TIENES QUE PEGAR LOS OTROS DOS ARCHIVOS ADJUNTOS ( A LA IZQUIERDA DE LA PANTALLA EN PYCHARM:
    #           PROYECTO\VENV\LIB\SITE-PACKAGES
    #     ESAS LIBRERIAS QUE PEGASTE, CONTIENE UN ARCHIVO QUE ES "tommy" EL CUAL SE APROVECHA DE LA BIBLIOTECA DE NUM2WORDS
    #   PARA QUE ESTE SCRIP FUNCIONE.
