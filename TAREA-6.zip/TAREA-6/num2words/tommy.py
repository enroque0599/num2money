def T(n):
    from num2words import num2words
    c = num2words(int(n), lang='es')
    if str(int(n))[len(str(int(n)))-1:len(str(int(n)))] == '1':
        c = c.replace('uno', 'un')
    print('\n   Son:', c, 'pesos con', int((n-int(n))*100), '/100 M.N.')
    print('\n       #Tommy´s-Rules')

#print(T(eval(input("n= "))))    #Prueba
